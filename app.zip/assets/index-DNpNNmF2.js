class I {
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, q.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_athenawasmdecoder_free(e, 0);
  }
  decode(e) {
    const r = me(e, n.__wbindgen_malloc), s = i, _ = n.athenawasmdecoder_decode(this.__wbg_ptr, r, s);
    return u.__wrap(_);
  }
  constructor() {
    const e = n.athenawasmdecoder_new();
    return this.__wbg_ptr = e >>> 0, q.register(this, this.__wbg_ptr, this), this;
  }
  reset() {
    n.athenawasmdecoder_reset(this.__wbg_ptr);
  }
  set_clock_kind(e) {
    const r = V(e, n.__wbindgen_malloc, n.__wbindgen_realloc), s = i;
    n.athenawasmdecoder_set_clock_kind(this.__wbg_ptr, r, s);
  }
  set_max_buffer_frames(e) {
    n.athenawasmdecoder_set_max_buffer_frames(this.__wbg_ptr, e);
  }
  set_reorder_window_ms(e) {
    n.athenawasmdecoder_set_reorder_window_ms(this.__wbg_ptr, e);
  }
  set_use_device_timestamps(e) {
    n.athenawasmdecoder_set_use_device_timestamps(this.__wbg_ptr, e);
  }
}
Symbol.dispose && (I.prototype[Symbol.dispose] = I.prototype.free);
class u {
  static __wrap(e) {
    e = e >>> 0;
    const r = Object.create(u.prototype);
    return r.__wbg_ptr = e, C.register(r, r.__wbg_ptr, r), r;
  }
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, C.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_athenawasmoutput_free(e, 0);
  }
  get accgyro_samples() {
    const e = n.athenawasmoutput_accgyro_samples(this.__wbg_ptr);
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  get accgyro_timestamps_ms() {
    const e = n.athenawasmoutput_accgyro_timestamps_ms(this.__wbg_ptr);
    var r = R(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 8, 8), r;
  }
  get battery_samples() {
    const e = n.athenawasmoutput_battery_samples(this.__wbg_ptr);
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  get battery_timestamps_ms() {
    const e = n.athenawasmoutput_battery_timestamps_ms(this.__wbg_ptr);
    var r = R(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 8, 8), r;
  }
  get eeg_channel_count() {
    return n.athenawasmoutput_eeg_channel_count(this.__wbg_ptr) >>> 0;
  }
  get eeg_samples() {
    const e = n.athenawasmoutput_eeg_samples(this.__wbg_ptr);
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  get eeg_timestamps_ms() {
    const e = n.athenawasmoutput_eeg_timestamps_ms(this.__wbg_ptr);
    var r = R(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 8, 8), r;
  }
  get optics_channel_count() {
    return n.athenawasmoutput_optics_channel_count(this.__wbg_ptr) >>> 0;
  }
  get optics_samples() {
    const e = n.athenawasmoutput_optics_samples(this.__wbg_ptr);
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  get optics_timestamps_ms() {
    const e = n.athenawasmoutput_optics_timestamps_ms(this.__wbg_ptr);
    var r = R(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 8, 8), r;
  }
}
Symbol.dispose && (u.prototype[Symbol.dispose] = u.prototype.free);
class O {
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, ge.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_eegbands_free(e, 0);
  }
  static get alpha() {
    const e = n.eegbands_alpha();
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  static get beta() {
    const e = n.eegbands_beta();
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  static get delta() {
    const e = n.eegbands_delta();
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  static get gamma() {
    const e = n.eegbands_gamma();
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  static get theta() {
    const e = n.eegbands_theta();
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
}
Symbol.dispose && (O.prototype[Symbol.dispose] = O.prototype.free);
class x {
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, P.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmalphabumpdetector_free(e, 0);
  }
  min_samples() {
    return n.wasmalphabumpdetector_min_samples(this.__wbg_ptr) >>> 0;
  }
  name() {
    let e, r;
    try {
      const s = n.wasmalphabumpdetector_name(this.__wbg_ptr);
      return e = s[0], r = s[1], g(s[0], s[1]);
    } finally {
      n.__wbindgen_free(e, r, 1);
    }
  }
  constructor(e, r) {
    const s = n.wasmalphabumpdetector_new(e, r);
    return this.__wbg_ptr = s >>> 0, P.register(this, this.__wbg_ptr, this), this;
  }
  process(e) {
    const r = l(e, n.__wbindgen_malloc), s = i, _ = n.wasmalphabumpdetector_process(this.__wbg_ptr, r, s);
    return _ === 0 ? void 0 : m.__wrap(_);
  }
  reset() {
    n.wasmalphabumpdetector_reset(this.__wbg_ptr);
  }
  set_baseline_smoothing(e) {
    n.wasmalphabumpdetector_set_baseline_smoothing(this.__wbg_ptr, e);
  }
  set_threshold(e) {
    n.wasmalphabumpdetector_set_threshold(this.__wbg_ptr, e);
  }
}
Symbol.dispose && (x.prototype[Symbol.dispose] = x.prototype.free);
class m {
  static __wrap(e) {
    e = e >>> 0;
    const r = Object.create(m.prototype);
    return r.__wbg_ptr = e, B.register(r, r.__wbg_ptr, r), r;
  }
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, B.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmalphabumpresult_free(e, 0);
  }
  get alpha_power() {
    return n.wasmalphabumpresult_alpha_power(this.__wbg_ptr);
  }
  get baseline() {
    return n.wasmalphabumpresult_baseline(this.__wbg_ptr);
  }
  is_high() {
    return n.wasmalphabumpresult_is_high(this.__wbg_ptr) !== 0;
  }
  is_low() {
    return n.wasmalphabumpresult_is_low(this.__wbg_ptr) !== 0;
  }
  get previous_state() {
    const e = n.wasmalphabumpresult_previous_state(this.__wbg_ptr);
    let r;
    return e[0] !== 0 && (r = g(e[0], e[1]).slice(), n.__wbindgen_free(e[0], e[1] * 1, 1)), r;
  }
  get state() {
    let e, r;
    try {
      const s = n.wasmalphabumpresult_state(this.__wbg_ptr);
      return e = s[0], r = s[1], g(s[0], s[1]);
    } finally {
      n.__wbindgen_free(e, r, 1);
    }
  }
  get state_changed() {
    return n.wasmalphabumpresult_state_changed(this.__wbg_ptr) !== 0;
  }
}
Symbol.dispose && (m.prototype[Symbol.dispose] = m.prototype.free);
class j {
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, N.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmalphapeakmodel_free(e, 0);
  }
  min_samples() {
    return n.wasmalphapeakmodel_min_samples(this.__wbg_ptr) >>> 0;
  }
  name() {
    let e, r;
    try {
      const s = n.wasmalphapeakmodel_name(this.__wbg_ptr);
      return e = s[0], r = s[1], g(s[0], s[1]);
    } finally {
      n.__wbindgen_free(e, r, 1);
    }
  }
  constructor(e, r) {
    const s = n.wasmalphapeakmodel_new(e, r);
    return this.__wbg_ptr = s >>> 0, N.register(this, this.__wbg_ptr, this), this;
  }
  process(e) {
    const r = l(e, n.__wbindgen_malloc), s = i, _ = n.wasmalphapeakmodel_process(this.__wbg_ptr, r, s);
    return _ === 0 ? void 0 : d.__wrap(_);
  }
  reset() {
    n.wasmalphapeakmodel_reset(this.__wbg_ptr);
  }
  set_smoothing(e) {
    n.wasmalphapeakmodel_set_smoothing(this.__wbg_ptr, e);
  }
}
Symbol.dispose && (j.prototype[Symbol.dispose] = j.prototype.free);
class d {
  static __wrap(e) {
    e = e >>> 0;
    const r = Object.create(d.prototype);
    return r.__wbg_ptr = e, D.register(r, r.__wbg_ptr, r), r;
  }
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, D.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmalphapeakresult_free(e, 0);
  }
  get alpha_power() {
    return n.wasmalphapeakresult_alpha_power(this.__wbg_ptr);
  }
  get long_term_peak_frequency() {
    return n.wasmalphapeakresult_long_term_peak_frequency(this.__wbg_ptr);
  }
  get peak_frequency() {
    return n.wasmalphapeakresult_peak_frequency(this.__wbg_ptr);
  }
  get peak_power() {
    return n.wasmalphapeakresult_peak_power(this.__wbg_ptr);
  }
  get smoothed_peak_frequency() {
    return n.wasmalphapeakresult_smoothed_peak_frequency(this.__wbg_ptr);
  }
  get snr() {
    return n.wasmalphapeakresult_snr(this.__wbg_ptr);
  }
}
Symbol.dispose && (d.prototype[Symbol.dispose] = d.prototype.free);
class w {
  static __wrap(e) {
    e = e >>> 0;
    const r = Object.create(w.prototype);
    return r.__wbg_ptr = e, T.register(r, r.__wbg_ptr, r), r;
  }
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, T.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmbandpowers_free(e, 0);
  }
  get alpha() {
    return n.wasmbandpowers_alpha(this.__wbg_ptr);
  }
  get beta() {
    return n.wasmbandpowers_beta(this.__wbg_ptr);
  }
  get delta() {
    return n.wasmbandpowers_delta(this.__wbg_ptr);
  }
  get gamma() {
    return n.wasmbandpowers_gamma(this.__wbg_ptr);
  }
  relative() {
    const e = n.wasmbandpowers_relative(this.__wbg_ptr);
    return w.__wrap(e);
  }
  get theta() {
    return n.wasmbandpowers_theta(this.__wbg_ptr);
  }
  get total() {
    return n.wasmbandpowers_total(this.__wbg_ptr);
  }
}
Symbol.dispose && (w.prototype[Symbol.dispose] = w.prototype.free);
class k {
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, K.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmcalmnessmodel_free(e, 0);
  }
  min_samples() {
    return n.wasmcalmnessmodel_min_samples(this.__wbg_ptr) >>> 0;
  }
  name() {
    let e, r;
    try {
      const s = n.wasmcalmnessmodel_name(this.__wbg_ptr);
      return e = s[0], r = s[1], g(s[0], s[1]);
    } finally {
      n.__wbindgen_free(e, r, 1);
    }
  }
  constructor(e, r) {
    const s = n.wasmcalmnessmodel_new(e, r);
    return this.__wbg_ptr = s >>> 0, K.register(this, this.__wbg_ptr, this), this;
  }
  process(e) {
    const r = l(e, n.__wbindgen_malloc), s = i, _ = n.wasmcalmnessmodel_process(this.__wbg_ptr, r, s);
    return _ === 0 ? void 0 : f.__wrap(_);
  }
  reset() {
    n.wasmcalmnessmodel_reset(this.__wbg_ptr);
  }
  set_smoothing(e) {
    n.wasmcalmnessmodel_set_smoothing(this.__wbg_ptr, e);
  }
}
Symbol.dispose && (k.prototype[Symbol.dispose] = k.prototype.free);
class f {
  static __wrap(e) {
    e = e >>> 0;
    const r = Object.create(f.prototype);
    return r.__wbg_ptr = e, L.register(r, r.__wbg_ptr, r), r;
  }
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, L.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmcalmnessresult_free(e, 0);
  }
  get alpha_beta_ratio() {
    return n.wasmcalmnessresult_alpha_beta_ratio(this.__wbg_ptr);
  }
  get alpha_power() {
    return n.wasmcalmnessresult_alpha_power(this.__wbg_ptr);
  }
  get beta_power() {
    return n.wasmcalmnessresult_beta_power(this.__wbg_ptr);
  }
  percentage() {
    return n.wasmcalmnessresult_percentage(this.__wbg_ptr);
  }
  get score() {
    return n.wasmcalmnessresult_score(this.__wbg_ptr);
  }
  get smoothed_score() {
    return n.wasmcalmnessresult_smoothed_score(this.__wbg_ptr);
  }
  state_description() {
    let e, r;
    try {
      const s = n.wasmcalmnessresult_state_description(this.__wbg_ptr);
      return e = s[0], r = s[1], g(s[0], s[1]);
    } finally {
      n.__wbindgen_free(e, r, 1);
    }
  }
  get theta_level() {
    return n.wasmcalmnessresult_theta_level(this.__wbg_ptr);
  }
  get theta_power() {
    return n.wasmcalmnessresult_theta_power(this.__wbg_ptr);
  }
}
Symbol.dispose && (f.prototype[Symbol.dispose] = f.prototype.free);
class S {
  __destroy_into_raw() {
    const e = this.__wbg_ptr;
    return this.__wbg_ptr = 0, U.unregister(this), e;
  }
  free() {
    const e = this.__destroy_into_raw();
    n.__wbg_wasmeegpreprocessor_free(e, 0);
  }
  detrend_mode() {
    let e, r;
    try {
      const s = n.wasmeegpreprocessor_detrend_mode(this.__wbg_ptr);
      return e = s[0], r = s[1], g(s[0], s[1]);
    } finally {
      n.__wbindgen_free(e, r, 1);
    }
  }
  get enabled() {
    return n.wasmeegpreprocessor_enabled(this.__wbg_ptr) !== 0;
  }
  constructor(e, r, s) {
    var _ = ue(s) ? 0 : V(s, n.__wbindgen_malloc, n.__wbindgen_realloc), a = i;
    const o = n.wasmeegpreprocessor_new(e, r, _, a);
    if (o[2]) throw de(o[1]);
    return this.__wbg_ptr = o[0] >>> 0, U.register(this, this.__wbg_ptr, this), this;
  }
  notch_frequencies_hz() {
    const e = n.wasmeegpreprocessor_notch_frequencies_hz(this.__wbg_ptr);
    var r = p(e[0], e[1]).slice();
    return n.__wbindgen_free(e[0], e[1] * 4, 4), r;
  }
  get preserve_raw() {
    return n.wasmeegpreprocessor_preserve_raw(this.__wbg_ptr) !== 0;
  }
  process(e) {
    const r = l(e, n.__wbindgen_malloc), s = i, _ = n.wasmeegpreprocessor_process(this.__wbg_ptr, r, s);
    var a = p(_[0], _[1]).slice();
    return n.__wbindgen_free(_[0], _[1] * 4, 4), a;
  }
  reference_mode() {
    let e, r;
    try {
      const s = n.wasmeegpreprocessor_reference_mode(this.__wbg_ptr);
      return e = s[0], r = s[1], g(s[0], s[1]);
    } finally {
      n.__wbindgen_free(e, r, 1);
    }
  }
  reset() {
    n.wasmeegpreprocessor_reset(this.__wbg_ptr);
  }
  update_layout(e, r) {
    n.wasmeegpreprocessor_update_layout(this.__wbg_ptr, e, r);
  }
}
Symbol.dispose && (S.prototype[Symbol.dispose] = S.prototype.free);
function te(t, e) {
  const r = l(t, n.__wbindgen_malloc), s = i;
  return n.alpha_power(r, s, e);
}
function re(t, e) {
  const r = l(t, n.__wbindgen_malloc), s = i, _ = n.band_powers(r, s, e);
  return w.__wrap(_);
}
function ne(t, e) {
  const r = l(t, n.__wbindgen_malloc), s = i;
  return n.beta_power(r, s, e);
}
function se(t) {
  const e = l(t, n.__wbindgen_malloc), r = i, s = n.compute_power_spectrum(e, r);
  var _ = p(s[0], s[1]).slice();
  return n.__wbindgen_free(s[0], s[1] * 4, 4), _;
}
function _e(t, e, r, s) {
  const _ = l(t, n.__wbindgen_malloc), a = i;
  return n.custom_band_power(_, a, e, r, s);
}
function oe(t, e) {
  const r = l(t, n.__wbindgen_malloc), s = i;
  return n.delta_power(r, s, e);
}
function ae(t, e) {
  const r = l(t, n.__wbindgen_malloc), s = i;
  return n.gamma_power(r, s, e);
}
function ie(t, e) {
  const r = n.get_fft_frequencies(t, e);
  var s = p(r[0], r[1]).slice();
  return n.__wbindgen_free(r[0], r[1] * 4, 4), s;
}
function ce() {
  let t, e;
  try {
    const r = n.get_version();
    return t = r[0], e = r[1], g(r[0], r[1]);
  } finally {
    n.__wbindgen_free(t, e, 1);
  }
}
function pe() {
  n.init();
}
function le(t, e) {
  const r = l(t, n.__wbindgen_malloc), s = i;
  return n.theta_power(r, s, e);
}
function J() {
  return { __proto__: null, "./eeg_wasm_bg.js": { __proto__: null, __wbg___wbindgen_throw_81fc77679af83bc6: function(e, r) {
    throw new Error(g(e, r));
  }, __wbg_now_88621c9c9a4f3ffc: function() {
    return Date.now();
  }, __wbindgen_cast_0000000000000001: function(e, r) {
    return g(e, r);
  }, __wbindgen_init_externref_table: function() {
    const e = n.__wbindgen_externrefs, r = e.grow(4);
    e.set(0, void 0), e.set(r + 0, void 0), e.set(r + 1, null), e.set(r + 2, true), e.set(r + 3, false);
  } } };
}
const q = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_athenawasmdecoder_free(t >>> 0, 1)), C = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_athenawasmoutput_free(t >>> 0, 1)), ge = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_eegbands_free(t >>> 0, 1)), P = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmalphabumpdetector_free(t >>> 0, 1)), B = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmalphabumpresult_free(t >>> 0, 1)), N = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmalphapeakmodel_free(t >>> 0, 1)), D = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmalphapeakresult_free(t >>> 0, 1)), T = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmbandpowers_free(t >>> 0, 1)), K = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmcalmnessmodel_free(t >>> 0, 1)), L = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmcalmnessresult_free(t >>> 0, 1)), U = typeof FinalizationRegistry > "u" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((t) => n.__wbg_wasmeegpreprocessor_free(t >>> 0, 1));
function p(t, e) {
  return t = t >>> 0, G().subarray(t / 4, t / 4 + e);
}
function R(t, e) {
  return t = t >>> 0, we().subarray(t / 8, t / 8 + e);
}
let b = null;
function G() {
  return (b === null || b.byteLength === 0) && (b = new Float32Array(n.memory.buffer)), b;
}
let y = null;
function we() {
  return (y === null || y.byteLength === 0) && (y = new Float64Array(n.memory.buffer)), y;
}
function g(t, e) {
  return t = t >>> 0, he(t, e);
}
let v = null;
function F() {
  return (v === null || v.byteLength === 0) && (v = new Uint8Array(n.memory.buffer)), v;
}
function ue(t) {
  return t == null;
}
function me(t, e) {
  const r = e(t.length * 1, 1) >>> 0;
  return F().set(t, r / 1), i = t.length, r;
}
function l(t, e) {
  const r = e(t.length * 4, 4) >>> 0;
  return G().set(t, r / 4), i = t.length, r;
}
function V(t, e, r) {
  if (r === void 0) {
    const c = z.encode(t), h = e(c.length, 1) >>> 0;
    return F().subarray(h, h + c.length).set(c), i = c.length, h;
  }
  let s = t.length, _ = e(s, 1) >>> 0;
  const a = F();
  let o = 0;
  for (; o < s; o++) {
    const c = t.charCodeAt(o);
    if (c > 127) break;
    a[_ + o] = c;
  }
  if (o !== s) {
    o !== 0 && (t = t.slice(o)), _ = r(_, s, s = o + t.length * 3, 1) >>> 0;
    const c = F().subarray(_ + o, _ + s), h = z.encodeInto(t, c);
    o += h.written, _ = r(_, s, o, 1) >>> 0;
  }
  return i = o, _;
}
function de(t) {
  const e = n.__wbindgen_externrefs.get(t);
  return n.__externref_table_dealloc(t), e;
}
let E = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
E.decode();
const fe = 2146435072;
let W = 0;
function he(t, e) {
  return W += e, W >= fe && (E = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true }), E.decode(), W = e), E.decode(F().subarray(t, t + e));
}
const z = new TextEncoder();
"encodeInto" in z || (z.encodeInto = function(t, e) {
  const r = z.encode(t);
  return e.set(r), { read: t.length, written: r.length };
});
let i = 0, n;
function X(t, e) {
  return n = t.exports, b = null, y = null, v = null, n.__wbindgen_start(), n;
}
async function be(t, e) {
  if (typeof Response == "function" && t instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming == "function") try {
      return await WebAssembly.instantiateStreaming(t, e);
    } catch (_) {
      if (t.ok && r(t.type) && t.headers.get("Content-Type") !== "application/wasm") console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", _);
      else throw _;
    }
    const s = await t.arrayBuffer();
    return await WebAssembly.instantiate(s, e);
  } else {
    const s = await WebAssembly.instantiate(t, e);
    return s instanceof WebAssembly.Instance ? { instance: s, module: t } : s;
  }
  function r(s) {
    switch (s) {
      case "basic":
      case "cors":
      case "default":
        return true;
    }
    return false;
  }
}
function Y(t) {
  if (n !== void 0) return n;
  t !== void 0 && (Object.getPrototypeOf(t) === Object.prototype ? { module: t } = t : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
  const e = J();
  t instanceof WebAssembly.Module || (t = new WebAssembly.Module(t));
  const r = new WebAssembly.Instance(t, e);
  return X(r);
}
async function Q(t) {
  if (n !== void 0) return n;
  t !== void 0 && (Object.getPrototypeOf(t) === Object.prototype ? { module_or_path: t } = t : console.warn("using deprecated parameters for the initialization function; pass a single object instead")), t === void 0 && (t = new URL("/assets/eeg_wasm_bg-CPbtJF8f.wasm", import.meta.url));
  const e = J();
  (typeof t == "string" || typeof Request == "function" && t instanceof Request || typeof URL == "function" && t instanceof URL) && (t = fetch(t));
  const { instance: r, module: s } = await be(await t, e);
  return X(r);
}
const xe = Object.freeze(Object.defineProperty({ __proto__: null, AthenaWasmDecoder: I, AthenaWasmOutput: u, EegBands: O, WasmAlphaBumpDetector: x, WasmAlphaBumpResult: m, WasmAlphaPeakModel: j, WasmAlphaPeakResult: d, WasmBandPowers: w, WasmCalmnessModel: k, WasmCalmnessResult: f, WasmEegPreprocessor: S, alpha_power: te, band_powers: re, beta_power: ne, compute_power_spectrum: se, custom_band_power: _e, default: Q, delta_power: oe, gamma_power: ae, get_fft_frequencies: ie, get_version: ce, init: pe, initSync: Y, theta_power: le }, Symbol.toStringTag, { value: "Module" }));
let M = null;
function Z(t) {
  return t !== null && typeof t == "object" && Object.getPrototypeOf(t) === Object.prototype;
}
function ye(t) {
  if (t !== void 0) return Z(t) && "module_or_path" in t ? t : { module_or_path: t };
}
function ve(t) {
  return Z(t) && "module" in t ? t : { module: t };
}
async function Fe(t) {
  return M || (M = Q(ye(t))), M;
}
function je(t) {
  return Y(ve(t));
}
function ke(t, e) {
  throw new Error("rPPG pipeline constructor is not available in eeg-web.");
}
const qe = "v1";
var H;
(function(t) {
  t.Idle = "idle", t.Connecting = "connecting", t.Connected = "connected", t.Streaming = "streaming", t.Degraded = "degraded", t.Reconnecting = "reconnecting", t.Disconnected = "disconnected", t.Error = "error";
})(H || (H = {}));
function ee(t, e = "auto") {
  return e === "raw" ? t.eegRaw ?? t.eeg : t.eeg;
}
function Ce(t, e, r = "auto") {
  var _a;
  const s = ee(t, r), _ = new Float32Array(s.samples.length);
  for (let a = 0; a < s.samples.length; a++) _[a] = ((_a = s.samples[a]) == null ? void 0 : _a[e]) ?? 0;
  return _;
}
function Pe(t, e = "auto") {
  const r = ee(t, e), s = new Float32Array(r.samples.length * r.channelCount);
  for (let _ = 0; _ < r.samples.length; _++) {
    const a = r.samples[_] ?? [];
    for (let o = 0; o < r.channelCount; o++) s[_ * r.channelCount + o] = a[o] ?? 0;
  }
  return s;
}
function ze(t, e) {
  const r = typeof t == "string" ? { mode: t } : t ?? {}, s = r.mode ?? "common-average", _ = (r.channels ?? []).map((a) => typeof a == "number" ? a : e.findIndex((o) => o === a)).filter((a) => Number.isInteger(a) && a >= 0);
  return { mode: s, channels: _ };
}
function Re(t) {
  const e = typeof t == "string" ? { mode: t } : t ?? {};
  return { mode: e.mode ?? "highpass", cutoff_hz: e.cutoffHz ?? 0.5, q: e.qualityFactor ?? 0.707 };
}
function Ae(t) {
  return t === false ? { mains_hz: null, harmonics: [], q: 20 } : { mains_hz: (t == null ? void 0 : t.mainsHz) ?? 60, harmonics: (t == null ? void 0 : t.harmonics) ?? [1, 2], q: (t == null ? void 0 : t.qualityFactor) ?? 20 };
}
function Ee(t) {
  const e = new Float32Array(t.samples.length * t.channelCount);
  for (let r = 0; r < t.samples.length; r++) {
    const s = t.samples[r] ?? [];
    for (let _ = 0; _ < t.channelCount; _++) e[r * t.channelCount + _] = s[_] ?? 0;
  }
  return e;
}
function Se(t, e) {
  const r = Math.floor(t.length / e), s = [];
  for (let _ = 0; _ < r; _++) {
    const a = new Array(e), o = _ * e;
    for (let c = 0; c < e; c++) a[c] = Number(t[o + c] ?? 0);
    s.push(a);
  }
  return s;
}
function We(t) {
  var _a;
  return { ...t, channelNames: t.channelNames.slice(), samples: t.samples.map((e) => e.slice()), timestampsMs: (_a = t.timestampsMs) == null ? void 0 : _a.slice() };
}
function A(t, e) {
  return t === "commonaverage" ? "common-average" : t === "customaverage" ? "custom-average" : t || e;
}
class Me {
  constructor(e = {}) {
    this.options = e, this.inner = null, this.layoutKey = "", this.readyPromise = null;
  }
  async ready() {
    this.options.enabled !== false && (this.readyPromise || (this.readyPromise = Fe().then(() => {
    })), await this.readyPromise);
  }
  reset() {
    var _a;
    (_a = this.inner) == null ? void 0 : _a.reset();
  }
  dispose() {
    var _a;
    (_a = this.inner) == null ? void 0 : _a.free(), this.inner = null, this.layoutKey = "";
  }
  processSignalBlock(e) {
    const r = We(e);
    if (this.options.enabled === false) return { eeg: r, eegProcessing: { applied: false, signalKind: "raw", rawAvailable: false, referenceMode: "none", detrendMode: "off", notchFrequenciesHz: [], stageOrder: [] } };
    const s = this.ensureInner(e), _ = s.process(Ee(r)), a = { ...r, samples: Se(_, r.channelCount) }, o = [...Array.from(s.notch_frequencies_hz()).length > 0 ? ["notch"] : [], ...A(s.detrend_mode(), "off") !== "off" ? ["detrend"] : [], ...A(s.reference_mode(), "none") !== "none" ? ["rereference"] : []];
    return { eeg: a, eegRaw: s.preserve_raw ? r : void 0, eegProcessing: { applied: true, signalKind: "processed", rawAvailable: s.preserve_raw, referenceMode: A(s.reference_mode(), "common-average"), detrendMode: A(s.detrend_mode(), "highpass"), notchFrequenciesHz: Array.from(s.notch_frequencies_hz()).map(Number), stageOrder: o } };
  }
  processFrame(e) {
    const { eeg: r, eegRaw: s, eegProcessing: _ } = this.processSignalBlock(e.eegRaw ?? e.eeg);
    return { ...e, eeg: r, eegRaw: s, eegProcessing: _ };
  }
  ensureInner(e) {
    var _a;
    const r = `${e.sampleRateHz}:${e.channelCount}:${e.channelNames.join(",")}:${JSON.stringify(this.options)}`, s = S;
    if (typeof s != "function") throw new Error("EEG preprocessing is unavailable because the WASM preprocessor export is missing.");
    if (!this.inner || this.layoutKey !== r) {
      (_a = this.inner) == null ? void 0 : _a.free();
      const _ = { enabled: this.options.enabled ?? true, preserve_raw: this.options.preserveRaw ?? true, reference: ze(this.options.reference, e.channelNames), detrend: Re(this.options.detrend), notch: Ae(this.options.notch) };
      this.inner = new s(e.sampleRateHz, e.channelCount, JSON.stringify(_)), this.layoutKey = r;
    } else this.inner.update_layout(e.sampleRateHz, e.channelCount);
    return this.inner;
  }
}
async function Ie(t = {}) {
  const e = new Me(t);
  return await e.ready(), e;
}
async function Be(t, e = {}) {
  const r = await Ie(e);
  try {
    return r.processFrame(t);
  } finally {
    r.dispose();
  }
}
class $ extends Error {
  constructor(e, r, s) {
    super(r), this.name = "ElataError", this.code = e, this.details = s == null ? void 0 : s.details, this.recoverable = s == null ? void 0 : s.recoverable, this.cause = s == null ? void 0 : s.cause;
  }
}
function Oe(t) {
  return typeof t == "object" && t !== null && t.name === "ElataError" && typeof t.code == "string";
}
function Ne(t, e = { code: "UNKNOWN", message: "Unknown error" }) {
  return Oe(t) ? t : t instanceof Error ? new $(e.code, e.message, { cause: t, details: { ...e.details || {}, originalMessage: t.message } }) : new $(e.code, e.message, { details: { ...e.details || {}, original: t } });
}
export {
  I as AthenaWasmDecoder,
  u as AthenaWasmOutput,
  O as EegBands,
  Me as EegPreprocessor,
  $ as ElataError,
  qe as HEADBAND_FRAME_SCHEMA_VERSION,
  H as HeadbandTransportState,
  x as WasmAlphaBumpDetector,
  m as WasmAlphaBumpResult,
  j as WasmAlphaPeakModel,
  d as WasmAlphaPeakResult,
  w as WasmBandPowers,
  k as WasmCalmnessModel,
  f as WasmCalmnessResult,
  S as WasmEegPreprocessor,
  te as alpha_power,
  Ne as asElataError,
  re as band_powers,
  ne as beta_power,
  se as compute_power_spectrum,
  Ie as createEegPreprocessor,
  ke as createRppgPipeline,
  _e as custom_band_power,
  oe as delta_power,
  ae as gamma_power,
  Ce as getEegChannelSamples,
  Pe as getEegInterleavedSamples,
  ee as getEegSignalBlock,
  ie as get_fft_frequencies,
  ce as get_version,
  pe as init,
  Fe as initEegWasm,
  je as initEegWasmSync,
  Y as initSync,
  Oe as isElataError,
  Be as processHeadbandFrame,
  le as theta_power,
  xe as wasm
};
