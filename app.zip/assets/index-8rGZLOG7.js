import { ElataError as A, HeadbandTransportState as l, asElataError as w, createEegPreprocessor as E, HEADBAND_FRAME_SCHEMA_VERSION as D } from "./index-DNpNNmF2.js";
import { AthenaWasmDecoder as G } from "./index-DNpNNmF2.js";
const S = ["TP9", "AF7", "AF8", "TP10", "AUX1", "AUX2", "AUX3", "AUX4"], y = ["TP9", "AF7", "AF8", "TP10"];
function g(c, e) {
  if (!c || typeof c != "object") return;
  const s = c[e];
  return typeof s == "function" ? s.call(c) : s;
}
function f(c) {
  return Array.isArray(c) ? c.filter((e) => typeof e == "number") : ArrayBuffer.isView(c) && !(c instanceof DataView) ? Array.from(c).filter((e) => typeof e == "number" && Number.isFinite(e)) : [];
}
class N {
  constructor(e = {}) {
    this.SERVICE_UUID = "0000fe8d-0000-1000-8000-00805f9b34fb", this.CHAR_UUIDS = { command: "273e0001-4c4d-454d-96be-f03bac821358", tp9: "273e0003-4c4d-454d-96be-f03bac821358", af7: "273e0004-4c4d-454d-96be-f03bac821358", af8: "273e0005-4c4d-454d-96be-f03bac821358", tp10: "273e0006-4c4d-454d-96be-f03bac821358", ppg1: "273e000f-4c4d-454d-96be-f03bac821358", ppg2: "273e0010-4c4d-454d-96be-f03bac821358", ppg3: "273e0011-4c4d-454d-96be-f03bac821358", athenaEeg: "273e0013-4c4d-454d-96be-f03bac821358", athenaOther: "273e0014-4c4d-454d-96be-f03bac821358" }, this.samplingRate = 256, this.numEegChannels = 4, this.eegNames = y.slice(), this.ppgNames = ["PPG1", "PPG2", "PPG3"], this.availablePpgNames = [], this.protocol = "classic", this.isAthena = false, this.opticsChannelCount = 0, this.availableCharacteristics = [], this.ppgMode = "none", this.athenaDecoder = null, this.device = null, this.server = null, this.service = null, this.commandChar = null, this.eegChars = {}, this.ppgChars = {}, this.athenaChars = {}, this.eegBuffers = {}, this.ppgBuffers = { PPG1: [], PPG2: [], PPG3: [] }, this.isStreaming = false, this.ppgSampleCount = 0, this.ppgFallbackTimer = null, this.onDataCallback = null, this.onPpgCallback = null, this.athenaDecoderFactory = e.athenaDecoderFactory, this.sleepMs = e.sleepMs || ((t) => new Promise((s) => setTimeout(s, t))), this.logger = e.logger, this.onDisconnected = e.onDisconnected;
  }
  getBoardInfo() {
    var _a;
    const e = ((_a = this.device) == null ? void 0 : _a.name) || "Unknown", t = e.toLowerCase().includes("synthetic") || e.toLowerCase().includes("muse-syn"), s = this.protocol === "athena";
    return { device_name: this.device ? `${e}` : "Muse / Synthetic Bridge", sample_rate_hz: this.samplingRate, channel_count: this.numEegChannels, eeg_channel_names: this.eegNames.slice(), board_id: t || s ? -1 : 21, protocol: s ? "athena" : "classic", optics_channel_count: s ? this.opticsChannelCount : 0, description: t ? "Synthetic EEG bridge emulating Muse protocol via BLE" : s ? "Muse S Athena (protocol v2) via Web Bluetooth" : "Muse S / Muse 2 EEG headband via Web Bluetooth" };
  }
  getCharacteristicInfo() {
    return { service_uuid: this.SERVICE_UUID, characteristics: this.availableCharacteristics.slice(), protocol: this.protocol };
  }
  decodeEegPacket(e) {
    const t = [];
    for (let s = 2; s + 2 < e.length; s += 3) {
      let i = e[s] << 4 | e[s + 1] >> 4, a = (e[s + 1] & 15) << 8 | e[s + 2];
      i = (i - 2048) * 125 / 256, a = (a - 2048) * 125 / 256, t.push(i, a);
    }
    return t;
  }
  decodePpgPacket(e) {
    if (e.length < 20) return { sequence: 0, samples: [] };
    const t = e[0] << 8 | e[1], s = e.slice(2, 20), i = [];
    for (let a = 0; a + 2 < s.length; a += 3) i.push(s[a] << 16 | s[a + 1] << 8 | s[a + 2]);
    return { sequence: t, samples: i };
  }
  splitPpgSamples(e) {
    const t = [], s = [], i = [];
    for (let a = 0; a < e.length; a += 3) e[a] !== void 0 && t.push(e[a]), e[a + 1] !== void 0 && s.push(e[a + 1]), e[a + 2] !== void 0 && i.push(e[a + 2]);
    return { ir: t, nearIr: s, red: i };
  }
  async prepareSession() {
    var _a;
    if (!navigator.bluetooth) throw new A("BLE_UNAVAILABLE", "Web Bluetooth not available in this browser", { recoverable: false, details: { platform: typeof navigator < "u" ? navigator.userAgent : "unknown" } });
    if (this.device = await navigator.bluetooth.requestDevice({ filters: [{ services: [this.SERVICE_UUID] }], optionalServices: [this.SERVICE_UUID] }), this.device.addEventListener("gattserverdisconnected", () => {
      this.isStreaming = false, this.commandChar = null, this.logger && this.logger("gatt disconnected"), this.onDisconnected && this.onDisconnected();
    }), this.server = await ((_a = this.device.gatt) == null ? void 0 : _a.connect()) ?? null, !this.server) throw new A("BLE_GATT_CONNECT_FAILED", "Failed to connect to GATT server", { recoverable: true });
    this.service = await this.server.getPrimaryService(this.SERVICE_UUID);
    const e = await this.service.getCharacteristics();
    this.availableCharacteristics = e.map((s) => s.uuid.toLowerCase());
    const t = this.availableCharacteristics.includes(this.CHAR_UUIDS.athenaEeg) && this.availableCharacteristics.includes(this.CHAR_UUIDS.athenaOther);
    this.protocol = t ? "athena" : "classic", this.isAthena = t, this.commandChar = await this.service.getCharacteristic(this.CHAR_UUIDS.command);
    try {
      await this.commandChar.startNotifications(), this.commandChar.addEventListener("characteristicvaluechanged", () => {
      });
    } catch {
    }
    if (this.isAthena) this.samplingRate = 256, this.numEegChannels = 8, this.eegNames = S.slice(), this.opticsChannelCount = 8, this.ppgMode = "athena", this.athenaChars.EEG = await this.service.getCharacteristic(this.CHAR_UUIDS.athenaEeg), this.athenaChars.OTHER = await this.service.getCharacteristic(this.CHAR_UUIDS.athenaOther), this.eegChars = {}, this.ppgChars = {};
    else {
      this.opticsChannelCount = 0, this.eegNames = y.slice(), this.numEegChannels = 4, this.availablePpgNames = [], this.eegChars.TP9 = await this.service.getCharacteristic(this.CHAR_UUIDS.tp9), this.eegChars.AF7 = await this.service.getCharacteristic(this.CHAR_UUIDS.af7), this.eegChars.AF8 = await this.service.getCharacteristic(this.CHAR_UUIDS.af8), this.eegChars.TP10 = await this.service.getCharacteristic(this.CHAR_UUIDS.tp10), this.ppgChars = {};
      try {
        this.ppgChars.PPG1 = await this.service.getCharacteristic(this.CHAR_UUIDS.ppg1), this.availablePpgNames.push("PPG1");
      } catch {
      }
      try {
        this.ppgChars.PPG2 = await this.service.getCharacteristic(this.CHAR_UUIDS.ppg2), this.availablePpgNames.push("PPG2");
      } catch {
      }
      try {
        this.ppgChars.PPG3 = await this.service.getCharacteristic(this.CHAR_UUIDS.ppg3), this.availablePpgNames.push("PPG3");
      } catch {
      }
      const s = Object.keys(this.ppgChars).length;
      s === 1 ? (this.ppgMode = "interleaved", this.availablePpgNames = this.ppgNames.slice()) : s >= 2 ? this.ppgMode = "per-channel" : (this.ppgMode = "none", this.availablePpgNames = []);
    }
  }
  async sendCommand(e) {
    if (!this.commandChar) return;
    const t = new Uint8Array(e.length + 2);
    t[0] = e.length + 1;
    for (let i = 0; i < e.length; i++) t[i + 1] = e.charCodeAt(i);
    t[t.length - 1] = 10;
    const s = this.commandChar;
    typeof s.writeValueWithoutResponse == "function" ? await s.writeValueWithoutResponse(t) : await this.commandChar.writeValue(t);
  }
  processClassicEegBuffers() {
    const e = Math.min(this.eegBuffers.TP9.length, this.eegBuffers.AF7.length, this.eegBuffers.AF8.length, this.eegBuffers.TP10.length);
    if (e < 12) return;
    const t = [], s = Math.min(e, 24);
    for (let i = 0; i < s; i++) t.push([this.eegBuffers.TP9.shift(), this.eegBuffers.AF7.shift(), this.eegBuffers.AF8.shift(), this.eegBuffers.TP10.shift()]);
    this.onDataCallback && t.length > 0 && this.onDataCallback(t);
  }
  async startStream(e, t = null) {
    if (this.isStreaming) return;
    if (!this.commandChar) throw new Error("Muse not connected");
    this.onDataCallback = e, this.onPpgCallback = t, this.isStreaming = true, this.ppgSampleCount = 0, this.ppgFallbackTimer !== null && (clearTimeout(this.ppgFallbackTimer), this.ppgFallbackTimer = null), this.eegBuffers = {};
    for (const a of this.eegNames) this.eegBuffers[a] = [];
    for (const a of this.ppgNames) this.ppgBuffers[a] = [];
    if (this.isAthena) {
      if (!this.athenaDecoderFactory) throw new Error("Athena support requires an Athena decoder factory");
      this.athenaDecoder ? this.athenaDecoder.reset() : this.athenaDecoder = this.athenaDecoderFactory(), this.athenaDecoder.set_use_device_timestamps(true), this.athenaDecoder.set_clock_kind("windowed"), this.athenaDecoder.set_reorder_window_ms(0);
      const a = (n) => {
        var _a;
        const r = n.target.value;
        if (!r) return;
        const d = new Uint8Array(r.buffer, r.byteOffset, r.byteLength);
        let h;
        try {
          h = (_a = this.athenaDecoder) == null ? void 0 : _a.decode(d);
        } catch (u) {
          this.logger && this.logger(`athena decode error: ${String(u)}`);
          return;
        }
        const o = f(g(h, "eeg_samples")), m = Number(g(h, "eeg_channel_count") || 0);
        if (o.length > 0 && m > 0 && this.onDataCallback) {
          this.numEegChannels !== m && (this.numEegChannels = m, this.eegNames = S.slice(0, m));
          const u = [], P = Math.floor(o.length / m);
          for (let C = 0; C < P; C++) {
            const b = new Array(m), _ = C * m;
            for (let v = 0; v < m; v++) b[v] = o[_ + v];
            u.push(b);
          }
          u.length > 0 && this.onDataCallback(u);
        }
        if (this.onPpgCallback) {
          const u = f(g(h, "optics_samples")), P = Number(g(h, "optics_channel_count") || 0);
          P > 0 && (this.opticsChannelCount = P);
          const C = f(g(h, "accgyro_samples")), b = f(g(h, "battery_samples"));
          (u.length > 0 || C.length > 0 || b.length > 0) && this.onPpgCallback("athena", { optics: { samples: u, channel_count: P, timestamps_ms: f(g(h, "optics_timestamps_ms")) }, accgyro: { samples: C, timestamps_ms: f(g(h, "accgyro_timestamps_ms")) }, battery: { samples: b, timestamps_ms: f(g(h, "battery_timestamps_ms")) } });
        }
      };
      for (const n of Object.values(this.athenaChars)) await n.startNotifications(), n.addEventListener("characteristicvaluechanged", a);
      await this.sendCommand("v6"), await this.sleepMs(200), await this.sendCommand("s"), await this.sleepMs(200), await this.sendCommand("h"), await this.sleepMs(200), await this.sendCommand("p1041"), await this.sleepMs(200), await this.sendCommand("s"), await this.sleepMs(200), await this.sendCommand("dc001"), await this.sleepMs(50), await this.sendCommand("dc001"), await this.sleepMs(100), await this.sendCommand("s");
      return;
    }
    const s = (a) => (n) => {
      const r = n.target.value;
      if (!r) return;
      const d = new Uint8Array(r.buffer, r.byteOffset, r.byteLength), h = this.decodeEegPacket(d);
      this.eegBuffers[a].push(...h), this.processClassicEegBuffers();
    };
    for (const [a, n] of Object.entries(this.eegChars)) await n.startNotifications(), n.addEventListener("characteristicvaluechanged", s(a));
    const i = (a) => (n) => {
      const r = n.target.value;
      if (!r) return;
      const d = new Uint8Array(r.buffer, r.byteOffset, r.byteLength), h = this.decodePpgPacket(d);
      if (h.samples.length !== 0) if (this.ppgSampleCount += h.samples.length, this.ppgMode === "interleaved") {
        const o = this.splitPpgSamples(h.samples);
        this.ppgBuffers.PPG1.push(...o.ir), this.ppgBuffers.PPG2.push(...o.nearIr), this.ppgBuffers.PPG3.push(...o.red), this.onPpgCallback && this.onPpgCallback("interleaved", { sequence: h.sequence, ...o });
      } else this.ppgBuffers[a].push(...h.samples), this.onPpgCallback && this.onPpgCallback(a, h);
    };
    for (const [a, n] of Object.entries(this.ppgChars)) await n.startNotifications(), n.addEventListener("characteristicvaluechanged", i(a));
    await this.sendCommand("v1"), await this.sendCommand("p21"), await this.sendCommand("d"), this.ppgFallbackTimer = window.setTimeout(async () => {
      this.ppgSampleCount > 0 || (await this.sendCommand("h"), await this.sendCommand("p50"), await this.sendCommand("d"));
    }, 3e3);
  }
  async stopStream() {
    if (!this.isStreaming) return;
    this.commandChar && await this.sendCommand("h");
    const e = this.isAthena ? Object.values(this.athenaChars) : Object.values(this.eegChars);
    for (const t of e) try {
      await t.stopNotifications();
    } catch {
    }
    for (const t of Object.values(this.ppgChars)) try {
      await t.stopNotifications();
    } catch {
    }
    this.ppgFallbackTimer !== null && (clearTimeout(this.ppgFallbackTimer), this.ppgFallbackTimer = null), this.isStreaming = false;
  }
  async releaseSession() {
    var _a, _b;
    await this.stopStream(), ((_b = (_a = this.device) == null ? void 0 : _a.gatt) == null ? void 0 : _b.connected) && this.device.gatt.disconnect(), this.device = null, this.server = null, this.service = null, this.commandChar = null, this.eegChars = {}, this.ppgChars = {}, this.athenaChars = {}, this.athenaDecoder = null, this.isAthena = false, this.protocol = "classic", this.opticsChannelCount = 0, this.availablePpgNames = [], this.ppgFallbackTimer !== null && (clearTimeout(this.ppgFallbackTimer), this.ppgFallbackTimer = null);
  }
}
class I {
  constructor(e = {}) {
    var _a;
    this.sequenceId = 0, this._connected = false, this.eegProcessor = null, this.pendingPpgRows = [], this.pendingPpgChannelNames = ["PPG1", "PPG2", "PPG3"], this.pendingOptics = null, this.pendingAccgyro = null, this.pendingBattery = null, this.ppgPerChannel = { PPG1: [], PPG2: [], PPG3: [] }, this.sourceName = e.sourceName || "muse-ble", this.eegProcessingOptions = e.eegProcessing === false ? { enabled: false } : e.eegProcessing === true || e.eegProcessing == null ? {} : e.eegProcessing, !e.device && !((_a = e.deviceOptions) == null ? void 0 : _a.athenaDecoderFactory) && console.warn("[BleTransport] No athenaDecoderFactory provided. Muse S Athena devices will fail to decode \u2014 pass athenaDecoderFactory: () => new AthenaWasmDecoder() in deviceOptions."), this.device = e.device || new N({ ...e.deviceOptions || {}, onDisconnected: () => {
      this._connected = false, this.emitStatus(l.Disconnected, "gatt disconnected", "BLE_GATT_DISCONNECTED", true);
    } });
  }
  getBoardInfo() {
    return this.device.getBoardInfo();
  }
  getCharacteristicInfo() {
    return this.device.getCharacteristicInfo();
  }
  getIsAthena() {
    return this.device.isAthena;
  }
  getEegNames() {
    return this.device.eegNames.slice();
  }
  getOpticsChannelCount() {
    return this.device.opticsChannelCount;
  }
  emitStatus(e, t, s, i) {
    this.onStatus && this.onStatus({ state: e, atMs: performance.now(), reason: t, errorCode: s, recoverable: i });
  }
  rowsFromFlat(e, t) {
    if (!e || !t || t <= 0) return [];
    const s = [], i = Math.floor(e.length / t);
    for (let a = 0; a < i; a++) {
      const n = new Array(t), p = a * t;
      for (let r = 0; r < t; r++) n[r] = e[p + r];
      s.push(n);
    }
    return s;
  }
  collectPerChannelPpg() {
    const e = this.getClassicPpgChannelNames();
    if (!e.length) return;
    const t = Math.min(...e.map((i) => this.ppgPerChannel[i].length));
    if (t <= 0) return;
    this.pendingPpgChannelNames = e;
    const s = [];
    for (let i = 0; i < t; i++) s.push(e.map((a) => this.ppgPerChannel[a].shift()));
    this.pendingPpgRows.push(...s);
  }
  getClassicPpgChannelNames() {
    const e = (this.device.availablePpgNames ?? []).filter((t) => t === "PPG1" || t === "PPG2" || t === "PPG3");
    return e.length > 0 ? e : ["PPG1", "PPG2", "PPG3"];
  }
  handlePpg(e, t) {
    if (!t) return;
    if (e === "athena") {
      const i = t, a = i.optics;
      if (a && a.samples.length > 0) {
        const r = a.channel_count || this.device.opticsChannelCount || 0, d = this.rowsFromFlat(a.samples, r);
        d.length > 0 && (this.pendingOptics = { sampleRateHz: 64, channelNames: Array.from({ length: r }, (h, o) => `OPTICS${o + 1}`), channelCount: r, samples: d, timestampsMs: a.timestamps_ms || [], clockSource: "device" });
      }
      const n = i.accgyro;
      if (n && n.samples.length > 0) {
        const r = this.rowsFromFlat(n.samples, 6);
        r.length > 0 && (this.pendingAccgyro = { sampleRateHz: 52, channelNames: ["ACC_X", "ACC_Y", "ACC_Z", "GYRO_X", "GYRO_Y", "GYRO_Z"], channelCount: 6, samples: r, timestampsMs: n.timestamps_ms || [], clockSource: "device" });
      }
      const p = i.battery;
      p && p.samples.length > 0 && (this.pendingBattery = { samples: p.samples.slice(), timestampsMs: p.timestamps_ms || [], clockSource: "device" });
      return;
    }
    if (e === "interleaved") {
      const i = t, a = Math.min(i.ir.length, i.nearIr.length, i.red.length);
      for (let n = 0; n < a; n++) this.pendingPpgRows.push([i.ir[n], i.nearIr[n], i.red[n]]);
      this.pendingPpgChannelNames = ["PPG1", "PPG2", "PPG3"];
      return;
    }
    if (e !== "PPG1" && e !== "PPG2" && e !== "PPG3") return;
    const s = t;
    !s.samples || s.samples.length === 0 || (this.ppgPerChannel[e].push(...s.samples), this.collectPerChannelPpg());
  }
  async connect() {
    this.emitStatus(l.Connecting);
    try {
      await this.device.prepareSession(), this._connected = true, this.emitStatus(l.Connected);
    } catch (e) {
      const t = w(e, { code: "BLE_CONNECT_FAILED", message: "Failed to connect to BLE device" });
      throw this.emitStatus(l.Error, t.message, t.code, t.recoverable), t;
    }
  }
  async startStreaming() {
    this._connected || await this.connect(), await this.start();
  }
  async disconnect() {
    try {
      await this.device.releaseSession(), this._connected = false, this.emitStatus(l.Disconnected);
    } catch (e) {
      const t = w(e, { code: "BLE_DISCONNECT_FAILED", message: "Failed to disconnect BLE device" });
      throw this.emitStatus(l.Error, t.message, t.code, t.recoverable), t;
    }
  }
  async start() {
    this.emitStatus(l.Streaming);
    try {
      this.eegProcessor || (this.eegProcessor = await E(this.eegProcessingOptions)), this.eegProcessor.reset(), await this.device.startStream((e) => {
        var _a;
        this.sequenceId += 1;
        let t = { schemaVersion: D, source: this.sourceName, sequenceId: this.sequenceId, emittedAtMs: performance.now(), eeg: { sampleRateHz: this.device.samplingRate, channelNames: this.device.eegNames.slice(), channelCount: this.device.numEegChannels, samples: e.map((s) => s.slice()), clockSource: this.device.isAthena ? "device" : "local" } };
        t = ((_a = this.eegProcessor) == null ? void 0 : _a.processFrame(t)) ?? t, this.pendingPpgRows.length > 0 && (t.ppgRaw = { sampleRateHz: 64, channelNames: this.pendingPpgChannelNames.slice(), channelCount: this.pendingPpgChannelNames.length, samples: this.pendingPpgRows.splice(0, this.pendingPpgRows.length), clockSource: "local" }), this.pendingOptics && (t.optics = this.pendingOptics, this.pendingOptics = null), this.pendingAccgyro && (t.accgyro = this.pendingAccgyro, this.pendingAccgyro = null), this.pendingBattery && (t.battery = this.pendingBattery, this.pendingBattery = null), this.onFrame && t.eeg.samples.length > 0 && this.onFrame(t);
      }, (e, t) => {
        this.handlePpg(e, t);
      });
    } catch (e) {
      const t = w(e, { code: "BLE_START_FAILED", message: "Failed to start BLE streaming" });
      throw this.emitStatus(l.Error, t.message, t.code, t.recoverable), t;
    }
  }
  async stop() {
    var _a;
    try {
      await this.device.stopStream(), (_a = this.eegProcessor) == null ? void 0 : _a.dispose(), this.eegProcessor = null, this.emitStatus(l.Connected);
    } catch (e) {
      const t = w(e, { code: "BLE_STOP_FAILED", message: "Failed to stop BLE streaming" });
      throw this.emitStatus(l.Error, t.message, t.code, t.recoverable), t;
    }
  }
}
function F() {
  if (typeof navigator > "u") return { supported: false, isIOS: false, message: "Web Bluetooth requires a browser environment." };
  if (navigator.bluetooth) return { supported: true };
  const c = navigator.userAgent;
  return /iPhone|iPad|iPod/i.test(c) || navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1 ? { supported: false, isIOS: true, message: "Web Bluetooth is not supported by Safari or Chrome on iOS. Please use Bluefy \u2014 a free browser app that enables Web Bluetooth on iPhone and iPad." } : { supported: false, isIOS: false, message: "Web Bluetooth is not supported in this browser. Please use Chrome to connect your headband." };
}
export {
  G as AthenaWasmDecoder,
  I as BleTransport,
  N as MuseBleDevice,
  F as checkWebBluetooth
};
